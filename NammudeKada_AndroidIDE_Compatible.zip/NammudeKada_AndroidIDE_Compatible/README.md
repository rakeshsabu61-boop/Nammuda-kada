# Nammude Kada — Android project

This is the native Android starter for Nammude Kada.

## Open on AndroidIDE
1. Extract this ZIP.
2. In AndroidIDE choose **Open existing project** and select the extracted `NammudeKada_RealApp_Starter` folder.
3. Let Gradle sync finish.
4. Use the Run/Build action to create the debug APK.

This package includes a `gradlew` launcher. AndroidIDE can use its installed Gradle toolchain. If the launcher reports that Gradle is missing, open AndroidIDE Terminal and run `pkg install gradle`, then reopen the project.

The current app is a local prototype: customer/shop/admin flows are present, but production cloud backend, OTP, push notifications, maps/live tracking and payment gateway still need to be connected.
