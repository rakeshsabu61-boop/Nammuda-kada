@echo off
call gradlew %*
