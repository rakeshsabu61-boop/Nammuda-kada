package com.nammudekada.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout body; TextView cartText;
    ArrayList<String> cart = new ArrayList<>(); int subtotal=0;

    String[] shops={"ABC Supermarket","Nanthirikkal Mart","Fresh Choice","Kundara Family Store"};
    String[][] items={
      {"Rice 1 kg|60","Milk 1 L|30","Sugar 1 kg|50","Sunflower Oil 1 L|145"},
      {"Rice 1 kg|62","Bread|45","Eggs 6|42","Tea 250 g|95"},
      {"Rice 1 kg|61","Milk 1 L|31","Biscuit|30","Soap|38"},
      {"Rice 1 kg|59","Sugar 1 kg|49","Oil 1 L|140","Salt 1 kg|25"}
    };

    @Override public void onCreate(Bundle b){
      super.onCreate(b); shell(); customer();
    }

    TextView t(String s,int z){ TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.DKGRAY);v.setPadding(12,12,12,12);return v; }
    Button b(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);return x;}
    void shell(){
      LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);
      LinearLayout head=new LinearLayout(this);head.setPadding(12,12,12,4);
      TextView logo=t("🛍️ Nammude Kada",24);head.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
      cartText=t("Cart 0",14);head.addView(cartText);all.addView(head);
      ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(12,4,12,80);sc.addView(body);all.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this);
      Button c=b("Customer"),s=b("Shop"),a=b("Admin");nav.addView(c,new LinearLayout.LayoutParams(0,-2,1));nav.addView(s,new LinearLayout.LayoutParams(0,-2,1));nav.addView(a,new LinearLayout.LayoutParams(0,-2,1));
      c.setOnClickListener(v->customer());s.setOnClickListener(v->shop());a.setOnClickListener(v->admin());all.addView(nav);setContentView(all);
    }
    void clear(){body.removeAllViews();}
    void customer(){
      clear();body.addView(t("📍 Nearby shops",23));body.addView(t("Choose a shop. The shop's own person delivers your order.",14));
      for(int i=0;i<shops.length;i++){final int q=i;body.addView(t("🏪 "+shops[i]+"\nOpen • local delivery",18));Button v=b("View shop");body.addView(v);v.setOnClickListener(x->products(q));}
      Button o=b("📦 My orders");body.addView(o);o.setOnClickListener(v->orders());
    }
    void products(int shop){
      clear();body.addView(t("← "+shops[shop],23));
      for(String p:items[shop]){String[] a=p.split("\\|");String n=a[0];int price=Integer.parseInt(a[1]);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(t(n+"\\n₹"+price,17),new LinearLayout.LayoutParams(0,-2,1));
        Button add=b("+ Add");row.addView(add);add.setOnClickListener(v->{cart.add(n);subtotal+=price;cartText.setText("Cart "+cart.size());Toast.makeText(this,"Added",Toast.LENGTH_SHORT).show();});body.addView(row);
      }
      Button co=b("🛒 Checkout");body.addView(co);co.setOnClickListener(v->checkout());
    }
    void checkout(){
      clear();body.addView(t("Checkout",23));
      if(cart.size()==0){body.addView(t("Cart empty",17));return;}
      body.addView(t("Items: "+cart.size()+"\\nSubtotal: ₹"+subtotal+"\\nDelivery: ₹20\\nTotal: ₹"+(subtotal+20),17));
      EditText name=new EditText(this);name.setHint("Customer name");body.addView(name);
      EditText address=new EditText(this);address.setHint("House name / full address");body.addView(address);
      Spinner pay=new Spinner(this);pay.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Cash on Delivery","UPI (ready for gateway integration)"}));body.addView(pay);
      Button place=b("Place order");body.addView(place);
      place.setOnClickListener(v->{if(name.length()==0||address.length()==0){Toast.makeText(this,"Name and address required",Toast.LENGTH_SHORT).show();return;}
        getPreferences(0).edit().putString("order","NK-1001|"+(subtotal+20)+"|Preparing").apply();
        cart.clear();subtotal=0;cartText.setText("Cart 0");clear();body.addView(t("✅ Order placed",25));body.addView(t("Order NK-1001\\nShop has received your order.\\nDelivery will be done by the shop.",17));Button tr=b("Track order");body.addView(tr);tr.setOnClickListener(x->orders());});
    }
    void orders(){clear();body.addView(t("📦 My Orders",23));String x=getPreferences(0).getString("order","");body.addView(t(x.length()==0?"No orders yet.":x+"\\n\\nPreparing → Ready → Out for delivery → Delivered",17));}
    void shop(){
      clear();body.addView(t("🏪 Shop dashboard",23));body.addView(t("ABC Supermarket • Open\\nToday: 12 orders",17));
      body.addView(t("🔔 New order NK-1001\\nRice ×2 • Milk ×1\\nTotal ₹220",17));Button ac=b("Accept order");body.addView(ac);TextView st=t("Waiting",15);body.addView(st);
      ac.setOnClickListener(v->{st.setText("Accepted → Preparing → Ready");ac.setEnabled(false);});
      body.addView(t("Delivery person",20));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Rajan","Shibu"}));body.addView(sp);
      Button as=b("Assign delivery");body.addView(as);as.setOnClickListener(v->Toast.makeText(this,"Delivery assigned",Toast.LENGTH_SHORT).show());
      body.addView(t("Products & stock",20));body.addView(t("Rice ₹60 • Stock 25\\nMilk ₹30 • Stock 18\\nSugar ₹50 • Stock 12\\nOil ₹145 • Stock 9",16));
    }
    void admin(){
      clear();body.addView(t("🛠️ Admin dashboard",23));body.addView(t("Shops 4 • Customers 24 • Orders 38\\nCommission ₹1,240",17));
      body.addView(t("Shop approval",20));body.addView(t("New Star Grocery • Kundara",16));Button ap=b("Approve");body.addView(ap);ap.setOnClickListener(v->{ap.setText("Approved ✓");ap.setEnabled(false);});
      body.addView(t("Orders",20));body.addView(t("NK-1001 — Preparing\\nNK-1000 — Delivered\\nNK-999 — Out for delivery",16));
      body.addView(t("Settings",20));body.addView(t("Delivery fee • Commission • Shop status • Support",16));
    }
}