# Production backend to connect next

API/entities:
- users: id, phone, name, role(customer/shop_admin/delivery/admin)
- shops: id, owner_id, name, address, lat, lng, open, delivery_fee
- products: id, shop_id, name, price, stock, active
- orders: id, customer_id, shop_id, status, subtotal, delivery_fee, total, address, payment_status
- order_items: order_id, product_id, quantity, price
- delivery_staff: id, shop_id, name, phone, active
- order_events: order_id, status, timestamp

Required production services:
- Auth / OTP
- Cloud database
- Push notifications
- Maps/location
- Payment gateway (UPI)
- Secure server-side order/payment validation

The APK cannot safely contain real payment credentials or a public database secret.
